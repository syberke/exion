import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  Timestamp,
  writeBatch,
} from "firebase/firestore"
import { db } from "./firebase"
import { uploadToFolder, uploadMultipleToFolder, getFolderForEkskul } from "./folder-storage"
import type { Member, Schedule, Attendance, Achievement, Documentation, Event, EkskulType } from "../types"

// Generic CRUD operations
export class CRUDService<T> {
  constructor(private collectionName: string) {}

  async create(data: Omit<T, "id">): Promise<string> {
    try {
      if (!data || typeof data !== "object") {
        throw new Error("Invalid data provided for creation")
      }

      const docRef = await addDoc(collection(db, this.collectionName), {
        ...data,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
      return docRef.id
    } catch (error) {
      console.error(`Error creating ${this.collectionName}:`, error)
      throw new Error(
        `Failed to create ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async read(id: string): Promise<T | null> {
    try {
      if (!id || typeof id !== "string") {
        throw new Error("Invalid ID provided")
      }

      const docRef = doc(db, this.collectionName, id)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as T
      }
      return null
    } catch (error) {
      console.error(`Error reading ${this.collectionName}:`, error)
      throw new Error(
        `Failed to read ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async update(id: string, data: Partial<T>): Promise<void> {
    try {
      if (!id || typeof id !== "string") {
        throw new Error("Invalid ID provided")
      }
      if (!data || typeof data !== "object") {
        throw new Error("Invalid data provided for update")
      }

      const docRef = doc(db, this.collectionName, id)
      await updateDoc(docRef, {
        ...data,
        updatedAt: Timestamp.now(),
      })
    } catch (error) {
      console.error(`Error updating ${this.collectionName}:`, error)
      throw new Error(
        `Failed to update ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async delete(id: string): Promise<void> {
    try {
      if (!id || typeof id !== "string") {
        throw new Error("Invalid ID provided")
      }

      const docRef = doc(db, this.collectionName, id)
      await deleteDoc(docRef)
    } catch (error) {
      console.error(`Error deleting ${this.collectionName}:`, error)
      throw new Error(
        `Failed to delete ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async list(filters?: { field: string; operator: any; value: any }[]): Promise<T[]> {
    try {
      let q = collection(db, this.collectionName)

      if (filters && filters.length > 0) {
        const validFilters = filters.filter((f) => f.field && f.operator && f.value !== undefined)
        if (validFilters.length > 0) {
          const constraints = validFilters.map((filter) => where(filter.field, filter.operator, filter.value))
          q = query(q, ...constraints, orderBy("createdAt", "desc")) as any
        } else {
          q = query(q, orderBy("createdAt", "desc")) as any
        }
      } else {
        q = query(q, orderBy("createdAt", "desc")) as any
      }

      const querySnapshot = await getDocs(q)
      return querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as T[]
    } catch (error) {
      console.error(`Error listing ${this.collectionName}:`, error)
      return []
    }
  }

  subscribe(callback: (data: T[]) => void, filters?: { field: string; operator: any; value: any }[]): () => void {
    let q = collection(db, this.collectionName)

    if (filters) {
      const constraints = filters.map((filter) => where(filter.field, filter.operator, filter.value))
      q = query(q, ...constraints, orderBy("createdAt", "desc")) as any
    } else {
      q = query(q, orderBy("createdAt", "desc")) as any
    }

    return onSnapshot(q, (querySnapshot) => {
      const data = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as T[]
      callback(data)
    })
  }

  async bulkCreate(dataArray: Omit<T, "id">[]): Promise<string[]> {
    try {
      const batch = writeBatch(db)
      const docRefs: string[] = []

      dataArray.forEach((data) => {
        const docRef = doc(collection(db, this.collectionName))
        batch.set(docRef, {
          ...data,
          createdAt: Timestamp.now(),
          updatedAt: Timestamp.now(),
        })
        docRefs.push(docRef.id)
      })

      await batch.commit()
      return docRefs
    } catch (error) {
      console.error(`Error bulk creating ${this.collectionName}:`, error)
      throw new Error(
        `Failed to bulk create ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async bulkUpdate(updates: { id: string; data: Partial<T> }[]): Promise<void> {
    try {
      const batch = writeBatch(db)

      updates.forEach(({ id, data }) => {
        const docRef = doc(db, this.collectionName, id)
        batch.update(docRef, {
          ...data,
          updatedAt: Timestamp.now(),
        })
      })

      await batch.commit()
    } catch (error) {
      console.error(`Error bulk updating ${this.collectionName}:`, error)
      throw new Error(
        `Failed to bulk update ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }

  async bulkDelete(ids: string[]): Promise<void> {
    try {
      const batch = writeBatch(db)

      ids.forEach((id) => {
        const docRef = doc(db, this.collectionName, id)
        batch.delete(docRef)
      })

      await batch.commit()
    } catch (error) {
      console.error(`Error bulk deleting ${this.collectionName}:`, error)
      throw new Error(
        `Failed to bulk delete ${this.collectionName}: ${error instanceof Error ? error.message : "Unknown error"}`,
      )
    }
  }
}

// Specific service instances
export const membersService = new CRUDService<Member>("members")
export const schedulesService = new CRUDService<Schedule>("schedules")
export const attendanceService = new CRUDService<Attendance>("attendance")
export const achievementsService = new CRUDService<Achievement>("achievements")
export const documentationService = new CRUDService<Documentation>("documentation")
export const eventsService = new CRUDService<Event>("events")

// Specialized operations
export const memberOperations = {
  ...membersService,

  async getByEkskul(ekskulType: EkskulType): Promise<Member[]> {
    return membersService.list([{ field: "ekskulType", operator: "==", value: ekskulType }])
  },

  async getActiveMembers(ekskulType?: EkskulType): Promise<Member[]> {
    const filters = [{ field: "status", operator: "==", value: "active" }]
    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }
    return membersService.list(filters)
  },

  async updateWithPhoto(id: string, data: Partial<Member>, photoFile?: File): Promise<void> {
    const updateData = { ...data }

    if (photoFile) {
      const uploadResult = await uploadToFolder(photoFile, "members", data.ekskulType)
      updateData.photoUrl = uploadResult.url
    }

    return membersService.update(id, updateData)
  },

  async createWithPhoto(data: Omit<Member, "id">, photoFile?: File): Promise<string> {
    const createData = { ...data }

    if (photoFile) {
      const uploadResult = await uploadToFolder(photoFile, "members", data.ekskulType)
      createData.photoUrl = uploadResult.url
    }

    return membersService.create(createData)
  },

  async searchMembers(searchTerm: string, ekskulType?: EkskulType): Promise<Member[]> {
    // Note: Firestore doesn't support full-text search, so we'll get all members and filter client-side
    const filters = ekskulType ? [{ field: "ekskulType", operator: "==", value: ekskulType }] : undefined
    const allMembers = await membersService.list(filters)

    return allMembers.filter(
      (member) =>
        member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.class.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.studentId.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  },
}

export const attendanceOperations = {
  ...attendanceService,

  async markAttendance(
    memberIds: string[],
    scheduleId: string,
    ekskulType: EkskulType,
    status: "present" | "absent" | "late" | "excused" = "present",
    notes?: string,
  ): Promise<void> {
    const batch = writeBatch(db)

    memberIds.forEach((memberId) => {
      const attendanceRef = doc(collection(db, "attendance"))
      batch.set(attendanceRef, {
        memberId,
        scheduleId,
        ekskulType,
        status,
        notes: notes || "",
        date: Timestamp.now(),
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    })

    await batch.commit()
  },

  async getAttendanceByDateRange(ekskulType: EkskulType, startDate: Date, endDate: Date): Promise<Attendance[]> {
    return attendanceService.list([
      { field: "ekskulType", operator: "==", value: ekskulType },
      { field: "date", operator: ">=", value: Timestamp.fromDate(startDate) },
      { field: "date", operator: "<=", value: Timestamp.fromDate(endDate) },
    ])
  },

  async getAttendanceStats(
    ekskulType: EkskulType,
    memberId?: string,
  ): Promise<{
    totalSessions: number
    presentCount: number
    absentCount: number
    lateCount: number
    excusedCount: number
    attendanceRate: number
  }> {
    const filters = [{ field: "ekskulType", operator: "==", value: ekskulType }]
    if (memberId) {
      filters.push({ field: "memberId", operator: "==", value: memberId })
    }

    const attendance = await attendanceService.list(filters)

    const stats = {
      totalSessions: attendance.length,
      presentCount: attendance.filter((a) => a.status === "present").length,
      absentCount: attendance.filter((a) => a.status === "absent").length,
      lateCount: attendance.filter((a) => a.status === "late").length,
      excusedCount: attendance.filter((a) => a.status === "excused").length,
      attendanceRate: 0,
    }

    if (stats.totalSessions > 0) {
      stats.attendanceRate = Math.round(
        ((stats.presentCount + stats.lateCount + stats.excusedCount) / stats.totalSessions) * 100,
      )
    }

    return stats
  },
}

export const achievementOperations = {
  ...achievementsService,

  async createWithPhoto(data: Omit<Achievement, "id">, photoFile?: File): Promise<string> {
    const createData = { ...data }

    if (photoFile) {
      const folder = getFolderForEkskul(data.ekskulType)
      const uploadResult = await uploadToFolder(photoFile, folder, "achievements")
      createData.photoUrl = uploadResult.url
    }

    return achievementsService.create(createData)
  },

  async updateWithPhoto(id: string, data: Partial<Achievement>, photoFile?: File): Promise<void> {
    const updateData = { ...data }

    if (photoFile && data.ekskulType) {
      const folder = getFolderForEkskul(data.ekskulType)
      const uploadResult = await uploadToFolder(photoFile, folder, "achievements")
      updateData.photoUrl = uploadResult.url
    }

    return achievementsService.update(id, updateData)
  },

  async getByLevel(level: Achievement["level"], ekskulType?: EkskulType): Promise<Achievement[]> {
    const filters = [{ field: "level", operator: "==", value: level }]
    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }
    return achievementsService.list(filters)
  },

  async getRecentAchievements(ekskulType?: EkskulType, limit = 10): Promise<Achievement[]> {
    const filters = ekskulType ? [{ field: "ekskulType", operator: "==", value: ekskulType }] : undefined
    const achievements = await achievementsService.list(filters)
    return achievements.slice(0, limit)
  },
}

export const documentationOperations = {
  ...documentationService,

  async createWithPhotos(data: Omit<Documentation, "id">, photoFiles: File[]): Promise<string> {
    const folder = getFolderForEkskul(data.ekskulType)
    const uploadResults = await uploadMultipleToFolder(photoFiles, folder, "documentation")
    const photoUrls = uploadResults.map((result) => result.url)

    return documentationService.create({
      ...data,
      photoUrls,
      image: photoUrls[0] || "",
    })
  },

  async addPhotos(id: string, photoFiles: File[]): Promise<void> {
    const doc = await documentationService.read(id)
    if (!doc) throw new Error("Documentation not found")

    const folder = getFolderForEkskul(doc.ekskulType)
    const uploadResults = await uploadMultipleToFolder(photoFiles, folder, "documentation")
    const newPhotoUrls = uploadResults.map((result) => result.url)
    const updatedPhotoUrls = [...(doc.photoUrls || []), ...newPhotoUrls]

    return documentationService.update(id, {
      photoUrls: updatedPhotoUrls,
      image: updatedPhotoUrls[0] || doc.image,
    })
  },

  async getByDateRange(ekskulType: EkskulType, startDate: Date, endDate: Date): Promise<Documentation[]> {
    return documentationService.list([
      { field: "ekskulType", operator: "==", value: ekskulType },
      { field: "date", operator: ">=", value: Timestamp.fromDate(startDate) },
      { field: "date", operator: "<=", value: Timestamp.fromDate(endDate) },
    ])
  },

  async searchDocumentation(searchTerm: string, ekskulType?: EkskulType): Promise<Documentation[]> {
    const filters = ekskulType ? [{ field: "ekskulType", operator: "==", value: ekskulType }] : undefined
    const allDocs = await documentationService.list(filters)

    return allDocs.filter(
      (doc) =>
        doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.participants?.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  },
}

export const scheduleOperations = {
  ...schedulesService,

  async getUpcomingSchedules(ekskulType?: EkskulType, days = 7): Promise<Schedule[]> {
    const startDate = new Date()
    const endDate = new Date()
    endDate.setDate(endDate.getDate() + days)

    const filters = [
      { field: "date", operator: ">=", value: Timestamp.fromDate(startDate) },
      { field: "date", operator: "<=", value: Timestamp.fromDate(endDate) },
    ]

    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }

    return schedulesService.list(filters)
  },

  async getSchedulesByDate(date: Date, ekskulType?: EkskulType): Promise<Schedule[]> {
    const startOfDay = new Date(date)
    startOfDay.setHours(0, 0, 0, 0)

    const endOfDay = new Date(date)
    endOfDay.setHours(23, 59, 59, 999)

    const filters = [
      { field: "date", operator: ">=", value: Timestamp.fromDate(startOfDay) },
      { field: "date", operator: "<=", value: Timestamp.fromDate(endOfDay) },
    ]

    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }

    return schedulesService.list(filters)
  },
}

export const eventOperations = {
  ...eventsService,

  async getUpcomingEvents(ekskulType?: EkskulType, limit = 10): Promise<Event[]> {
    const now = new Date()
    const filters = [{ field: "date", operator: ">=", value: Timestamp.fromDate(now) }]

    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }

    const events = await eventsService.list(filters)
    return events.slice(0, limit)
  },

  async getEventsByType(type: Event["type"], ekskulType?: EkskulType): Promise<Event[]> {
    const filters = [{ field: "type", operator: "==", value: type }]
    if (ekskulType) {
      filters.push({ field: "ekskulType", operator: "==", value: ekskulType })
    }
    return eventsService.list(filters)
  },
}

// Utility functions for cross-collection operations
export const adminOperations = {
  async getDashboardStats(ekskulType?: EkskulType): Promise<{
    totalMembers: number
    activeMembers: number
    totalDocumentation: number
    totalAchievements: number
    upcomingEvents: number
    attendanceRate: number
  }> {
    try {
      const [members, documentation, achievements, events, attendanceStats] = await Promise.all([
        memberOperations.getByEkskul(ekskulType!),
        ekskulType ? documentationService.list([{ field: "ekskulType", operator: "==", value: ekskulType }]) : [],
        ekskulType ? achievementsService.list([{ field: "ekskulType", operator: "==", value: ekskulType }]) : [],
        ekskulType ? eventOperations.getUpcomingEvents(ekskulType) : [],
        ekskulType ? attendanceOperations.getAttendanceStats(ekskulType) : null,
      ])

      return {
        totalMembers: members.length,
        activeMembers: members.filter((m) => m.status === "active").length,
        totalDocumentation: documentation.length,
        totalAchievements: achievements.length,
        upcomingEvents: events.length,
        attendanceRate: attendanceStats?.attendanceRate || 0,
      }
    } catch (error) {
      console.error("Error getting dashboard stats:", error)
      return {
        totalMembers: 0,
        activeMembers: 0,
        totalDocumentation: 0,
        totalAchievements: 0,
        upcomingEvents: 0,
        attendanceRate: 0,
      }
    }
  },
}
