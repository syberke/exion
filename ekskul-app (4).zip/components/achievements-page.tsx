"use client"

import { useState, useEffect } from "react"
import { Trophy, Medal, Award, Calendar } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getAchievements } from "@/lib/firebase-service"
import type { Achievement } from "@/types"

export default function AchievementsPage() {
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadAchievements = async () => {
      try {
        setLoading(true)
        const data = await getAchievements()
        setAchievements(data)
      } catch (error) {
        console.error("Error loading achievements:", error)
      } finally {
        setLoading(false)
      }
    }

    loadAchievements()
  }, [])

  const stats = [
    { icon: Trophy, label: "Total Prestasi", value: achievements.length.toString(), color: "text-yellow-600" },
    {
      icon: Medal,
      label: "Medali Emas",
      value: achievements.filter((a) => a.level === "Nasional").length.toString(),
      color: "text-yellow-500",
    },
    {
      icon: Award,
      label: "Penghargaan",
      value: achievements.filter((a) => a.category === "competition").length.toString(),
      color: "text-blue-600",
    },
    {
      icon: Calendar,
      label: "Tahun Aktif",
      value:
        new Set(
          achievements
            .map((a) => {
              const date = a.date?.toDate ? a.date.toDate() : new Date(a.date)
              return date.getFullYear()
            })
            .filter((year) => !isNaN(year)),
        ).size.toString() + "+",
      color: "text-green-600",
    },
  ]

  const levelColors = {
    Nasional: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    Provinsi: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    Regional: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    Daerah: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  }

  const getEkskulColor = (ekskulType: string) => {
    switch (ekskulType) {
      case "robotics":
        return "from-yellow-400 to-orange-500"
      case "silat":
        return "from-red-500 to-orange-500"
      case "futsal":
        return "from-green-500 to-emerald-500"
      case "band":
        return "from-purple-500 to-pink-500"
      default:
        return "from-blue-500 to-cyan-500"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen py-20 flex items-center justify-center">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
          <span className="text-muted-foreground">Memuat prestasi...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="font-heading font-bold text-4xl lg:text-5xl mb-6">
            Prestasi <span className="text-blue-600">SMA Negeri 1</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Kebanggaan kami atas pencapaian luar biasa siswa-siswi dalam berbagai kompetisi dan kejuaraan tingkat daerah
            hingga nasional.
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-muted rounded-full mb-4">
                    <Icon className={`h-8 w-8 ${stat.color}`} />
                  </div>
                  <div className="text-3xl font-bold mb-2">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Achievements Grid */}
        {achievements.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {achievements.map((achievement) => (
              <Card
                key={achievement.id}
                className="overflow-hidden hover:shadow-lg transition-shadow h-full flex flex-col"
              >
                <div className="relative">
                  <img
                    src={achievement.photoUrl || "/placeholder.svg?height=200&width=300"}
                    alt={achievement.title}
                    className="w-full h-48 object-cover"
                  />
                  <div
                    className={`absolute top-4 left-4 bg-gradient-to-r ${getEkskulColor(achievement.ekskulType)} px-3 py-1 rounded-full`}
                  >
                    <span className="text-white font-semibold text-sm capitalize">{achievement.ekskulType}</span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge
                      className={levelColors[achievement.level as keyof typeof levelColors] || levelColors.Regional}
                    >
                      {achievement.level}
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-lg line-clamp-2 flex-grow">{achievement.title}</h3>
                    <Badge variant="outline" className="ml-2 flex-shrink-0">
                      {(() => {
                        try {
                          const date = achievement.date?.toDate ? achievement.date.toDate() : new Date(achievement.date)
                          return date.getFullYear()
                        } catch {
                          return "N/A"
                        }
                      })()}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3 flex-grow">{achievement.description}</p>
                  <div className="flex items-center justify-between mt-auto">
                    <span className="text-sm font-medium text-blue-600 capitalize">{achievement.ekskulType}</span>
                    <Trophy className="h-5 w-5 text-yellow-600" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Trophy className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-muted-foreground mb-2">Belum Ada Prestasi</h3>
            <p className="text-muted-foreground">Prestasi akan ditampilkan di sini setelah ditambahkan oleh admin</p>
          </div>
        )}

        {/* Achievement Timeline */}
        {achievements.length > 0 && (
          <div className="mt-20">
            <h2 className="font-heading font-bold text-3xl text-center mb-12">Timeline Prestasi</h2>
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border"></div>
                {achievements.slice(0, 4).map((achievement, index) => (
                  <div key={achievement.id} className="relative flex items-start mb-8">
                    <div className="absolute left-2 w-4 h-4 bg-blue-600 rounded-full border-4 border-background"></div>
                    <div className="ml-12">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">
                          {(() => {
                            try {
                              const date = achievement.date?.toDate
                                ? achievement.date.toDate()
                                : new Date(achievement.date)
                              return date.getFullYear()
                            } catch {
                              return "N/A"
                            }
                          })()}
                        </Badge>
                        <Badge
                          className={levelColors[achievement.level as keyof typeof levelColors] || levelColors.Regional}
                        >
                          {achievement.level}
                        </Badge>
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{achievement.title}</h3>
                      <p className="text-muted-foreground">{achievement.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
