"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, X, CheckCircle, AlertCircle, File, ImageIcon } from "lucide-react"
import {
  uploadToCloudinary,
  uploadMultipleToCloudinary,
  validateFile,
  type UploadProgress,
  type UploadResult,
} from "@/lib/cloudinary-service"

interface CloudinaryUploadProps {
  onUploadComplete: (results: UploadResult[]) => void
  onUploadError?: (error: string) => void
  folder: string
  multiple?: boolean
  maxFiles?: number
  accept?: string
  className?: string
  tags?: string[]
}

const CloudinaryUpload = ({
  onUploadComplete,
  onUploadError,
  folder,
  multiple = false,
  maxFiles = 5,
  accept = "image/*",
  className = "",
  tags = [],
}: CloudinaryUploadProps) => {
  const [files, setFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<Record<number, UploadProgress>>({})
  const [error, setError] = useState<string>("")
  const [success, setSuccess] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || [])

    if (!multiple && selectedFiles.length > 1) {
      setError("Only one file can be uploaded at a time")
      return
    }

    if (selectedFiles.length > maxFiles) {
      setError(`Maximum ${maxFiles} files allowed`)
      return
    }

    // Validate each file
    const validationErrors: string[] = []
    const validFiles: File[] = []

    selectedFiles.forEach((file, index) => {
      const validation = validateFile(file)
      if (validation.valid) {
        validFiles.push(file)
      } else {
        validationErrors.push(`File ${index + 1}: ${validation.error}`)
      }
    })

    if (validationErrors.length > 0) {
      setError(validationErrors.join(", "))
      return
    }

    setFiles(validFiles)
    setError("")
    setSuccess(false)

    // Create previews for images
    const newPreviews: string[] = []
    validFiles.forEach((file) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          newPreviews.push(e.target?.result as string)
          if (newPreviews.length === validFiles.filter((f) => f.type.startsWith("image/")).length) {
            setPreviews(newPreviews)
          }
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    const droppedFiles = Array.from(event.dataTransfer.files)

    const syntheticEvent = {
      target: { files: droppedFiles },
    } as React.ChangeEvent<HTMLInputElement>

    handleFileSelect(syntheticEvent)
  }

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault()
  }

  const handleUpload = async () => {
    if (files.length === 0) return

    setUploading(true)
    setError("")
    setUploadProgress({})

    try {
      let results: UploadResult[]

      if (multiple && files.length > 1) {
        results = await uploadMultipleToCloudinary(files, folder, {
          tags,
          onProgress: (fileIndex, progress) => {
            setUploadProgress((prev) => ({
              ...prev,
              [fileIndex]: progress,
            }))
          },
        })
      } else {
        const result = await uploadToCloudinary(files[0], folder, {
          tags,
          onProgress: (progress) => {
            setUploadProgress({ 0: progress })
          },
        })
        results = [result]
      }

      setSuccess(true)
      onUploadComplete(results)

      // Reset form
      setTimeout(() => {
        setFiles([])
        setPreviews([])
        setUploadProgress({})
        setSuccess(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }, 2000)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Upload failed"
      setError(errorMessage)
      onUploadError?.(errorMessage)
    } finally {
      setUploading(false)
    }
  }

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index)
    const newPreviews = previews.filter((_, i) => i !== index)
    setFiles(newFiles)
    setPreviews(newPreviews)

    if (newFiles.length === 0 && fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const getOverallProgress = () => {
    const progressValues = Object.values(uploadProgress)
    if (progressValues.length === 0) return 0

    const totalProgress = progressValues.reduce((sum, progress) => sum + progress.percentage, 0)
    return Math.round(totalProgress / progressValues.length)
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Drop Zone */}
      <div
        className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors cursor-pointer"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <p className="text-lg font-medium text-gray-900 mb-2">Drop files here or click to browse</p>
        <p className="text-sm text-gray-500">{multiple ? "Select multiple files" : "Select a file"} to upload</p>
        <input
          ref={fileInputRef}
          type="file"
          multiple={multiple}
          accept={accept}
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>

      {/* Upload Button */}
      {files.length > 0 && (
        <Button onClick={handleUpload} disabled={uploading} className="w-full">
          {uploading ? "Uploading..." : `Upload ${files.length} file${files.length > 1 ? "s" : ""}`}
        </Button>
      )}

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Success Alert */}
      {success && (
        <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-600">Upload completed successfully!</AlertDescription>
        </Alert>
      )}

      {/* Upload Progress */}
      {uploading && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Uploading...</span>
            <span>{getOverallProgress()}%</span>
          </div>
          <Progress value={getOverallProgress()} className="w-full" />
        </div>
      )}

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-medium text-gray-900">Selected Files:</h4>
          {files.map((file, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                {file.type.startsWith("image/") ? (
                  <ImageIcon className="h-5 w-5 text-blue-500" />
                ) : (
                  <File className="h-5 w-5 text-gray-500" />
                )}
                <div>
                  <p className="text-sm font-medium text-gray-900">{file.name}</p>
                  <p className="text-xs text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {uploading && uploadProgress[index] !== undefined && (
                  <div className="w-24">
                    <Progress value={uploadProgress[index].percentage} className="h-2" />
                  </div>
                )}
                {!uploading && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      removeFile(index)
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Guidelines */}
      <div className="text-xs text-muted-foreground space-y-1">
        <p>• Maximum file size: 10MB</p>
        <p>• Supported formats: JPEG, PNG, GIF, WebP, PDF, Word documents</p>
        {multiple && <p>• Maximum {maxFiles} files at once</p>}
        <p>• Files will be stored securely in Cloudinary</p>
      </div>
    </div>
  )
}

export { CloudinaryUpload }
export default CloudinaryUpload
