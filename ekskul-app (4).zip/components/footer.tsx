"use client"

import { Mail, Phone, MapPin, Facebook, Instagram, Twitter, Youtube, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface FooterProps {
  onNavigate: (section: string) => void
}

export default function Footer({ onNavigate }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const currentYear = new Date().getFullYear()

  const quickLinks = [
    { name: "Beranda", section: "home" },
    { name: "Ekstrakurikuler", section: "extracurriculars" },
    { name: "Prestasi", section: "achievements" },
    { name: "Dokumentasi", section: "documentation" },
    { name: "Tentang Kami", section: "about" },
    { name: "Kontak", section: "contact" },
  ]

  const ekstrakurikuler = [
    { name: "Robotik", section: "robotik" },
    { name: "Futsal", section: "futsal" },
    { name: "Musik", section: "musik" },
    { name: "Pencak Silat", section: "silat" },
  ]

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Youtube, href: "#", label: "YouTube" },
  ]

  return (
    <footer className="hero-gradient text-white relative overflow-hidden">
      <div className="absolute inset-0 clean-pattern opacity-10"></div>

      <div className="relative container-responsive py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="space-y-6 sm:col-span-2 lg:col-span-1">
            <div>
              <h3 className="font-heading font-bold text-2xl mb-4">SMA Negeri 1</h3>
              <p className="text-white/80 leading-relaxed mb-6">
                Mengembangkan potensi siswa melalui berbagai kegiatan ekstrakurikuler yang berkualitas dan berprestasi.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-cyan-300 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-white/90 font-medium">Alamat Sekolah</p>
                  <p className="text-white/70 text-sm">Jl. Pendidikan No. 123, Jakarta Selatan 12345</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-cyan-300 flex-shrink-0" />
                <div>
                  <p className="text-white/90 font-medium">Telepon</p>
                  <p className="text-white/70 text-sm">(021) 1234-5678</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-cyan-300 flex-shrink-0" />
                <div>
                  <p className="text-white/90 font-medium">Email</p>
                  <p className="text-white/70 text-sm">info@sman1.sch.id</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Navigasi Cepat</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.section}>
                  <button
                    onClick={() => onNavigate(link.section)}
                    className="text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Ekstrakurikuler</h4>
            <ul className="space-y-3">
              {ekstrakurikuler.map((ekskul) => (
                <li key={ekskul.section}>
                  <button
                    onClick={() => onNavigate(ekskul.section)}
                    className="text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 text-left"
                  >
                    {ekskul.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Ikuti Kami</h4>

            <div className="flex gap-3 mb-6">
              {socialLinks.map((social) => {
                const Icon = social.icon
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    className="w-10 h-10 bg-white/10 hover:bg-cyan-500 rounded-lg flex items-center justify-center transition-all duration-300 hover:scale-110"
                    aria-label={social.label}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                )
              })}
            </div>

            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="p-4">
                <h5 className="font-semibold text-white mb-2">Newsletter</h5>
                <p className="text-white/70 text-sm mb-3">Dapatkan update terbaru tentang kegiatan ekstrakurikuler</p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="Email Anda"
                    className="flex-1 px-3 py-2 bg-white/20 border border-white/30 rounded-md text-white placeholder-white/50 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  />
                  <Button size="sm" className="bg-cyan-500 hover:bg-cyan-600 text-sm px-3">
                    Subscribe
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="text-white/70 text-sm">
                © {currentYear} SMA Negeri 1. Seluruh hak cipta dilindungi undang-undang.
              </p>
              <p className="text-white/60 text-xs mt-1">Dikembangkan dengan ❤️ untuk kemajuan pendidikan Indonesia</p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="flex gap-4 text-xs text-white/60">
                <button className="hover:text-white transition-colors">Kebijakan Privasi</button>
                <button className="hover:text-white transition-colors">Syarat & Ketentuan</button>
                <button className="hover:text-white transition-colors">Sitemap</button>
              </div>

              <Button onClick={scrollToTop} size="sm" className="bg-white/10 hover:bg-white/20 border border-white/30">
                <ArrowUp className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
